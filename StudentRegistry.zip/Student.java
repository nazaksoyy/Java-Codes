
public class Student {

	private String sid;
	private String sname;
	private String ssurname;
	private int scredit;
	private int courselimit;
	
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSsurname() {
		return ssurname;
	}
	public void setSsurname(String ssurname) {
		this.ssurname = ssurname;
	}
	public int getScredit() {
		return scredit;
	}
	public void setScredit(int scredit) {
		this.scredit = scredit;
	}
	public int getCourselimit() {
		return courselimit;
	}
	public void setCourselimit(int courselimit) {
		this.courselimit = courselimit;
	}
	
}
