
public class CarDealer {

		public static final int MAX_VEHICLE_AGE= 20;
		public static final int MIN_VEHICLE_AGE=0;
		public final static int MAX_NUMBER_OF_VEHICLE_THAT_CAN_BE_SOLD=10;
		public final static int MAX_VEHICLE_NAME_SIZE=15;
		public final static int MIN_VEHICLE_PRICE=0;
		public final static int MAX_VEHICLE_PRICE=1000000;
		public static final int MIN_TRUCK_TONNAGE=0;
		public static final int MAX_TRUCK_TONNAGE=5000;
		public static final int MIN_BUS_CAPACITY= 0;
		public static final int MAX_BUS_CAPACITY=100;
		public static final int MIN_BATTERY_CAPACITY=0;
		public static final int MAX_BATTERY_CAPACITY=600;
		public static final int MIN_FUEL_CAPACITY=0;
		public static final int MAX_FUEL_CAPACITY=80;

		//public static String round (double value)
			

}
