import file.InputDelegate;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputDelegate id = new InputDelegate();
		id.read("input.txt");
	}

}
