package vehicles;

public class Vehicle {

		public String age;
		public String model;
		public String price;
		public String type;
		
		
}
