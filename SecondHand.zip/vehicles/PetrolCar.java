package vehicles;

public class PetrolCar extends Cars{

		private String fcapacity;

		public String getFcapacity() {
			return fcapacity;
		}

		public void setFcapacity(String fcapacity) {
			this.fcapacity = fcapacity;
		}
		
}
