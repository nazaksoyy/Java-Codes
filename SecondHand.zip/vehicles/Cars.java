package vehicles;

public class Cars extends Vehicle {

	public String doornumber;
}
