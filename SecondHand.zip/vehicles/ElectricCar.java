package vehicles;

public class ElectricCar extends Cars{

		private String bcapacity;
			
		public String getBcapacity() {
			return bcapacity;
		}

		public void setBcapacity(String bcapacity) {
			this.bcapacity = bcapacity;
		}

	
		
		
}
